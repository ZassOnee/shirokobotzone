
require('./settings');
const fs = require('fs');
const pino = require('pino');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const ora = require('ora');
const readline = require('readline');
const figlet = require('figlet');
const CFonts = require('cfonts');
const gradient = require('gradient-string');
const FileType = require('file-type');
const qrcode = require('qrcode-terminal');
const { exec } = require('child_process');
const { Boom } = require('@hapi/boom');
const NodeCache = require('node-cache');
const PhoneNumber = require('awesome-phonenumber');
const { default: WAConnection, jidDecode, useMultiFileAuthState, Browsers, DisconnectReason, makeInMemoryStore, makeCacheableSignalKeyStore, fetchLatestWaWebVersion, proto, PHONENUMBER_MCC, getAggregateVotesInPollMessage } = require('@whiskeysockets/baileys');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))
const { color } = require('./lib/color.js');

const kuroinput = (query) => new Promise(resolve => rl.question(query, resolve));
const DataBase = require('./src/database');
const database = new DataBase();
(async () => {
	const loadData = await database.read()
	if (loadData && Object.keys(loadData).length === 0) {
		global.db = {
			users: {},
			game: {},
			groups: {},
			database: {},
			settings : {}, 
			...(loadData || {}),
		}
		await database.write(global.db)
	} else {
		global.db = loadData
	}
	
process.on('uncaughtException', logError);
process.on('unhandledRejection', logError);

	function logError(err) {
  const now = new Date();
  const tanggal = now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const jam = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

  const garisAtas = chalk.hex('#FF6666')('═'.repeat(60));
  const garisBawah = chalk.hex('#FFB6C1')('─'.repeat(60));
  const merahTebal = chalk.hex('#FF0000').bold;
  const putih = chalk.hex('#FFFFFF');
  const terang = chalk.hex('#FFFF33');

  console.log(`\n${garisAtas}`);
  console.log(chalk.bgHex('#B22222').hex('#FFFFFF').bold('❌ TERJADI ERROR'));
  console.log(`${putih('Tanggal :')} ${putih(tanggal)}`);
  console.log(`${putih('Jam     :')} ${terang(jam)}`);
  console.log(`${putih('Pesan   :')} ${merahTebal(err.message || err)}`);
  console.log(`${putih('Stack   :')}`);
  console.log(chalk.hex('#FFA07A')(err.stack || 'Stack tidak tersedia'));
  console.log(garisBawah);
}
	
	setInterval(async () => {
		if (global.db) await database.write(global.db)
	}, 30000)
})();

const { GroupUpdate, GroupParticipantsUpdate, MessagesUpsert, Solving, initializer } = require('./src/message');
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep } = require('./lib/function');

async function getPhoneNumber() {
    console.clear();
    console.log(gradient.instagram(figlet.textSync("YT NeoShiroko Labs", { font: "ANSI Shadow" })))
    console.log(chalk.yellowBright('\nMasukkan nomor WhatsApp kamu untuk mendapatkan code pairing.'));
    console.log(chalk.cyanBright('Contoh: 62xx'));

    const input = await kuroinput(chalk.blue('\n➤ Nomor WhatsApp : '));
    let phoneNumber = input.replace(/[^0-9]/g, '');

    if (!/^[1-9][0-9]{7,14}$/.test(phoneNumber)) {
        console.log(chalk.bgRed.white('\n[ERROR] Nomor tidak valid. Harus diawali kode negara dan panjang minimal 8 digit!'));
        return await getPhoneNumber();
    }

    return phoneNumber;
}

async function startingBot(pairingCode) {
	const { state, saveCreds } = await useMultiFileAuthState('session');
console.log(chalk.yellowBright(pairingCode 
  ? '➤ Menggunakan metode Pairing Code (nomor & password)' 
  : '➤ Menggunakan metode QR Code. Scan QR dari terminal...'));
	const { version } = await fetchLatestWaWebVersion()
	const msgRetryCounterCache = new NodeCache()
	
	const zassbtz = await WAConnection({
version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
browser: ['ios', 'Chrome', '10.15.7'],
printQRInTerminal: false, // nonaktifkan QR bawaan Baileys
logger: pino({ level: "silent" }),
auth: state,
generateHighQualityLinkPreview: true,     
getMessage: async (key) => {
if (store) {
const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
return msg?.message || undefined
}
return {
conversation: 'YT NeoShiroko Labs'
}}})
	
if (pairingCode && !zassbtz.authState.creds.registered) {

const phoneNumber = await getPhoneNumber();  
await exec('rm -rf ./session/*');  

// Loading animasi pairing code  
let i = 0;  
const anim = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'];  
process.stdout.write(chalk.blueBright(`\n Get pairing code `));  
const interval = setInterval(() => {  
    process.stdout.write('\r' + chalk.blueBright(` Get pairing code ${anim[i = ++i % anim.length]}`));  
}, 120);  

// Biarkan animasi tampil minimal 2 detik  
await new Promise(resolve => setTimeout(resolve, 2000));  

let code = await zassbtz.requestPairingCode(phoneNumber);  
clearInterval(interval);  
process.stdout.write('\n');  
code = code.match(/.{1,4}/g).join(" - ") || code;  

console.clear();  
console.log(gradient.pastel(figlet.textSync('Kode Pairing', { font: 'Big' })));  
console.log(chalk.cyanBright('\nSilakan salin kode berikut dan buka WhatsApp kamu:\n'));  
console.log(chalk.whiteBright.bgMagenta.bold(`  ${code}  `));  
console.log(chalk.greenBright('\nBuka WhatsApp > Perangkat Tertaut > Tambah Perangkat dan masukkan kode di atas.\n'));

}
	
	store?.bind(zassbtz.ev)
	
	await Solving(zassbtz, store)
	
	zassbtz.ev.on('creds.update', saveCreds)

// Handler koneksi
zassbtz.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, receivedPendingNotifications, qr } = update;
if (qr && !pairingCode) {
  qrcode.generate(qr, { small: true });
}
    if (connection === 'close') {
        const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
        switch (reason) {
            case DisconnectReason.connectionLost:
                console.log(chalk.redBright('[✘] Koneksi terputus. Menghubungkan ulang...'));
                startingBot();
                break;
            case DisconnectReason.connectionClosed:
                console.log(chalk.redBright('[✘] Koneksi ditutup. Menghubungkan ulang...'));
                startingBot();
                break;
            case DisconnectReason.restartRequired:
                console.log(chalk.yellowBright('[!] Proses menghubungkan bot...'));
                startingBot();
                break;
            case DisconnectReason.timedOut:
                console.log(chalk.redBright('[✘] Koneksi time out. Menghubungkan ulang...'));
                startingBot();
                break;
            case DisconnectReason.badSession:
                console.log(chalk.bgRed.white.bold('\n[!] Sesi rusak. Hapus session dan scan ulang.\n'));
                startingBot();
                break;
            case DisconnectReason.connectionReplaced:
                console.log(chalk.bgRed.white.bold('\n[!] Koneksi digantikan. silahkan ketik restart.\n'));
                startingBot();
                break;
            case DisconnectReason.loggedOut:
                console.log(chalk.redBright('[!] Telah logout. Menghapus session...'));
                exec('rm -rf ./session/*');
                process.exit(1);
                break;
            case DisconnectReason.Multidevicemismatch:
                console.log(chalk.redBright('[!] Multi-device mismatch. Scan ulang...'));
                exec('rm -rf ./session/*');
                process.exit(0);
                break;
            default:
                console.log(chalk.bgRed.white.bold(`[UNKNOWN] Disconnect Reason: ${reason}`));
                zassbtz.end();
        }
    }

    if (connection === 'open') {
        // Kirim pesan ke pemilik bot
        const ownerJid = zassbtz.user.id.split(":")[0] + "@s.whatsapp.net";
        await zassbtz.sendMessage(ownerJid, {
            text: `\`® Script : Kuroko V2\`\n\nJangan lupa untuk berlangganan YouTube developer -> https://youtube.com/@ZassOnee agar anda mendapatkan update terkini tentang script bot WhatsApp.`
        });

        // Tampilan sukses koneksi
        console.clear();
        console.log(gradient.rainbow(figlet.textSync('BOT TERSAMBUNG', { horizontalLayout: 'default' })));

        CFonts.say('welcome', {
            font: 'block',
            align: 'center',
            gradient: ['cyan', 'blue'],
        });

        console.log(chalk.greenBright.bold('\n[√] BERHASIL TERHUBUNG!\n'));
        console.log(chalk.cyanBright('───────────────────────────────'));
        console.log(chalk.yellow('┏━ Info Kontak & Sosmed ━━━━━━━'));
        console.log(chalk.yellow('┃'), chalk.green('YouTube   : @ZassOnee'));
        console.log(chalk.yellow('┃'), chalk.green('Instagram : @zass.id_'));
        console.log(chalk.yellow('┃'), chalk.green('Tiktok    : @zass.id'));
        console.log(chalk.yellow('┃'), chalk.green('Contact : 6285298027445'));
        console.log(chalk.cyanBright('───────────────────────────────\n'));

        CFonts.say('Made by Zass Offc', {
            font: 'chrome',
            align: 'center',
            gradient: ['red', 'magenta'],
        });
}

    await initializer(zassbtz);
    if (receivedPendingNotifications === 'true') {
        console.log(chalk.blue('[i] Mohon tunggu sebentar (~1 menit)...'));
    }
});
	
	zassbtz.ev.on('contacts.update', (update) => {
		for (let contact of update) {
			let id = zassbtz.decodeJid(contact.id)
			if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
		}
	});
	
	zassbtz.ev.on('call', async (call) => {
  if (!global.anticall) return;

  let botNumber = await zassbtz.decodeJid(zassbtz.user.id);

  for (let id of call) {
    if (id.status === 'offer') {
      let msg = await zassbtz.sendMessage(id.from, {
        text: `Saat Ini, Kami Tidak Dapat Menerima Panggilan ${id.isVideo ? 'Video' : 'Suara'}.\nJika @${id.from.split('@')[0]} Memerlukan Bantuan, Silakan Hubungi Owner :)`,
        mentions: [id.from]
      });

      await zassbtz.sendContact(id.from, global.owner, msg);
      await zassbtz.rejectCall(id.id, id.from);
    }
  }
});
	
	zassbtz.ev.on('contacts.update', (update) => {
		for (let contact of update) {
			let id = 
zassbtz.decodeJid(contact.id)
			if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
		}
});
// Tambahkan fungsi decodeJid aman
zassbtz.decodeJid = (jid) => {
  try {
    if (!jid || typeof jid !== 'string') return jid
    if (/:\d+@/gi.test(jid)) {
      const decode = jidDecode(jid)
      if (decode?.user && decode?.server) return `${decode.user}@${decode.server}`
    }
    return jid
  } catch {
    return jid
  }
}

    zassbtz.sendTextWithMentions = async (jid, text, quoted, options = {}) => zassbtz.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })

zassbtz.sendText = (jid, text, quoted = '', options) => zassbtz.sendMessage(jid, { text: text, ...options }, { quoted })

	
	zassbtz.ev.on('group-participants.update', async (anu) => {
if (!global.welcome) return
let botNumber = await zassbtz.decodeJid(zassbtz.user.id)
if (anu.participants.includes(botNumber)) return
try {
let metadata = await zassbtz.groupMetadata(anu.id)
let namagc = metadata.subject
let participants = anu.participants
for (let num of participants) {
let check = anu.author !== num && anu.author.length > 1
let tag = check ? [anu.author, num] : [num]
try {
ppuser = await zassbtz.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
if (anu.action == 'add') {
zassbtz.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} Telah Menambahkan @${num.split("@")[0]} Ke Dalam Grup Ini` : `┅═❏ *hai ka @${num.split("@")[0]}* ❏═┅‎\n▭▬▭▬▭▬▭▬▭▬▭▬▭\nSelamat Datang Di\nGrup : *${namagc}*\n▭▬▭▬▭▬▭▬▭▬▭▬▭\n\`TERIMAKASIH\`\nSudah Bergabung Di Grup kami Jangan lupa Baca Deskripsi Grup ya.\n\n> JADILAH MEMBER YANG BAIK & MEMATUHI PERATURAN`,
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '漏 Welcome Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029VadvvgF6rsQljgBc7D1t", mediaType: 1}}})
} 
if (anu.action == 'remove') { 
zassbtz.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} Telah Mengeluarkan @${num.split("@")[0]} Dari Grup Ini
` : `Selamat Tinggal ka @${num.split("@")[0]}\nSemoga tenang di alam sana 😓`,  
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '漏 Leaving Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029VadvvgF6rsQljgBc7D1t", mediaType: 1}}})
}
if (anu.action == "promote") {
zassbtz.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} Telah Menjadikan @${num.split("@")[0]} Sebagai Admin Grup Ini
`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '漏 Promote Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029VadvvgF6rsQljgBc7D1t", mediaType: 1}}})
}
if (anu.action == "demote") {
zassbtz.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} Telah Memberhentikan @${num.split("@")[0]} Sebagai Admin Grup Ini
`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '漏 Demote Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029VadvvgF6rsQljgBc7D1t", mediaType: 1}}})
}
} 
} catch (err) {
logError(err)
}})

zassbtz.ev.on('messages.upsert', async (message) => {
    let m = message.messages[0];
    if (!m.message) return;

    // 🔄 Auto-read Status dan Chat
    if (m.key?.remoteJid === 'status@broadcast') {
        if (global.autoreadsw) {
            zassbtz.readMessages([m.key]);
        }
    } else {
        if (global.autoread) {
            zassbtz.readMessages([m.key]);
        }
    }
    await MessagesUpsert(zassbtz, message, store);
});
	
zassbtz.sendTextWithMentions = async (jid, text, quoted, options = {}) => zassbtz.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })

	return zassbtz
}

const SESSION_PATH = path.join(__dirname, 'session', 'creds.json');
if (fs.existsSync(SESSION_PATH)) {
  console.log(chalk.greenBright('✓ Session ditemukan. Menghubungkan ulang ke WhatsApp...'));
  startingBot(true); // atau startingBot(false) tergantung metode login awal
  return; // Hentikan eksekusi agar tidak lanjut ke menu pilihan
}

setTimeout(() => {
  console.clear();

  // Judul utama
  console.log(gradient.instagram(figlet.textSync("KUROKO V2", { font: "ANSI Shadow" })))

  // Isi kotak dengan teks tengah
  const boxContent = [
    'Selamat datang di dunia penuh fitur dan keseruan!',
    'Silakan pilih metode login yang ingin kamu gunakan:',
    '',
    '1. Login dengan Pairing Code',
    '2. Login dengan QR Code'
  ];

  const boxWidth = 60;

  console.log(chalk.cyanBright(`╔${'═'.repeat(boxWidth)}╗`));
  boxContent.forEach(line => {
    const paddedLine = line.padStart(((boxWidth + line.length) / 2), ' ');
    console.log(chalk.cyanBright(`║${paddedLine.padEnd(boxWidth, ' ')}║`));
  });
  console.log(chalk.cyanBright(`╚${'═'.repeat(boxWidth)}╝\n`));

  // Tampilkan input setelah jeda kecil
  setTimeout(() => {
    console.log(chalk.magentaBright('➤ Silakan pilih metode login (1 / 2):'));
    rl.question(chalk.greenBright('• Pilihan Anda : '), async (answer) => {
      const pairingCode = answer.trim() === '1';
      await startingBot(pairingCode);
    });
  }, 300);

}, 1000);

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});