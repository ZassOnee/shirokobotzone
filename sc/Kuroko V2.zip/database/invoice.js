const { createCanvas, loadImage } = require('canvas');
const QRCode = require('qrcode');


async function sendInvoice(conn, m, items, namaPembeli = "Customer", statusPembayaran = "proses") {
  const canvas = createCanvas(720, 600);
  const ctx = canvas.getContext('2d');

  // Background putih
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Load Logo untuk background (cap blur)
  try {
    const logo = await loadImage('https://img1.pixhost.to/images/5289/592318768_media.jpg'); // Ganti URL jika perlu
    ctx.globalAlpha = 0.2;  // Efek transparansi
    ctx.drawImage(logo, (canvas.width - 200) / 2, (canvas.height - 200) / 2, 200, 200);
    ctx.globalAlpha = 1;  // Mengembalikan transparansi normal
  } catch (e) {
    console.warn('Logo gagal dimuat');
  }

  ctx.fillStyle = '#000000';
  ctx.textAlign = 'center';

  // Nama toko
  ctx.font = 'bold 32px Sans';
  ctx.fillText('RIKIONLINE.SHOP', canvas.width / 2, 50);

  // Info toko & sosmed horizontal
  ctx.font = '16px Sans';
  ctx.fillText('Toko Terbaik No.1, Indonesia', canvas.width / 2, 80);
  ctx.fillText('Telp: 085771555374', canvas.width / 2, 100);

  // Sosmed horizontal (memanjang)
  ctx.font = '14px Sans';
  ctx.fillText('YT: @rikishopreal   TT: @rikishopreal   IG: @riki.setore   Tele: @rikishopreal', canvas.width / 2, 120);

  // Garis pembatas
  ctx.beginPath();
  ctx.moveTo(40, 135);
  ctx.lineTo(canvas.width - 40, 135);
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Tanggal dan Pembeli
  const tanggal = new Date().toLocaleString('id-ID', {
  dateStyle: 'short',
  timeStyle: 'short',
  timeZone: 'Asia/Jakarta'
});
  ctx.textAlign = 'left';
  ctx.font = '14px Sans';
  ctx.fillText(`Tanggal : ${tanggal}`, 50, 160);
  ctx.fillText(`Pembeli : ${namaPembeli}`, 50, 180);

  // Garis pembatas bawah
  ctx.beginPath();
  ctx.moveTo(40, 195);
  ctx.lineTo(canvas.width - 40, 195);
  ctx.stroke();

  // Daftar belanja
  let startY = 220;
  let total = 0;
  ctx.font = '16px Sans';

  for (let item of items) {
    const hargaNum = parseInt(item.harga.replace(/\D/g, '')) || 0;
    total += hargaNum;

    // Nama barang kiri
    ctx.textAlign = 'left';
    ctx.fillText(`${item.nama}`, 50, startY);

    // Harga kanan
    ctx.textAlign = 'right';
    ctx.fillText(`Rp ${hargaNum.toLocaleString('id-ID')}`, canvas.width - 50, startY);

    startY += 30;
  }

  // Garis sebelum total
  ctx.beginPath();
  ctx.moveTo(40, startY);
  ctx.lineTo(canvas.width - 40, startY);
  ctx.stroke();

  // Total harga
  startY += 30;
  ctx.font = 'bold 18px Sans';
  ctx.textAlign = 'left';
  ctx.fillText('TOTAL', 50, startY);

  ctx.textAlign = 'right';
  ctx.fillText(`Rp ${total.toLocaleString('id-ID')}`, canvas.width - 50, startY);

  // Garis bawah total
  startY += 20;
  ctx.beginPath();
  ctx.moveTo(40, startY);
  ctx.lineTo(canvas.width - 40, startY);
  ctx.stroke();

  // Status pembayaran
  startY += 40;
  ctx.textAlign = 'center';
  ctx.font = '16px Sans';
  let status = 'STATUS: MENUNGGU PEMBAYARAN';
  if (statusPembayaran === "proses") status = 'STATUS: DIPROSES';
  else if (statusPembayaran === "berhasil") status = 'STATUS: BERHASIL';
  ctx.fillText(status, canvas.width / 2, startY);

  // Ucapan terima kasih
  startY += 40;
  ctx.font = '16px Sans';
  ctx.fillText('Terima kasih telah berbelanja!', canvas.width / 2, startY);
  ctx.fillText('Semoga harimu menyenangkan.', canvas.width / 2, startY + 25);

  // QR Code (bawah tengah)
  const qrText = 'https://wa.me/6285771555374';
  const qrBuffer = await QRCode.toBuffer(qrText, { margin: 1 });
  const qrImage = await loadImage(qrBuffer);
  const qrSize = 80;
const qrY = startY + 40; // kasih jarak setelah teks terakhir
ctx.drawImage(qrImage, (canvas.width - qrSize) / 2, qrY, qrSize, qrSize);

  // Footer
  ctx.font = 'italic 12px Sans';
ctx.fillStyle = '#555';
ctx.textAlign = 'center';
ctx.fillText('© RIKIONLINE.SHOP 2024-2025', canvas.width / 2, qrY + qrSize + 30);

  const buffer = canvas.toBuffer('image/png');
  await conn.sendMessage(m.chat, {
    image: buffer,
    fileName: 'struk.png',
    caption: `🧾 *Struk pembayaran Riki shop!*
    
*terimakasih sudah mempercayai kami*
*senang melayani anda jangan lupa*
*untuk mampir dan berbelanja lagu 🤗*`
  }, { quoted: m });
}

// Background dan medal online
const bgURL = 'https://img1.pixhost.to/images/5305/592505433_media.jpg'; // Background hitam emas
const medalURL = 'https://files.catbox.moe/jice1o.png';  // Icon medali emas

async function sendGameCertificate(conn, m, nama, juara, game, tanggal) {
  const canvas = createCanvas(1080, 720);
  const ctx = canvas.getContext('2d');

  // Load background
  const background = await loadImage(bgURL);
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  // Text alignment
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';

  // Tulis "SERTIFIKAT" dengan font estetik
  ctx.font = 'bold 72px Serif';
  ctx.fillStyle = '#C0C0C0'; // Emas terang
  ctx.shadowColor = 'rgba(0,0,0,0.5)';
  ctx.shadowBlur = 4;
  ctx.fillText('SERTIFIKAT', canvas.width / 2, 80);
  ctx.shadowBlur = 0;

  // Subjudul "PENGHARGAAN"
  ctx.font = 'italic 30px Sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('PENGHARGAAN', canvas.width / 2, 160);

  // Teks "Diberikan kepada"
  ctx.font = '22px Sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Dengan bangga diberikan kepada:', canvas.width / 2, 210);

  // Nama peserta, graffiti style
  ctx.font = 'bold italic 64px Sans-serif';
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
  gradient.addColorStop(0, '#C0C0C0');
  gradient.addColorStop(1, '#C0C0C0');
  ctx.fillStyle = gradient;
  ctx.fillText(nama.toUpperCase(), canvas.width / 2, 270);

  // Garis bawah nama dinamis
  const textMetrics = ctx.measureText(nama.toUpperCase());
  const lineWidth = textMetrics.width + 40; // Tambah sedikit biar pas

  ctx.beginPath();
  ctx.moveTo((canvas.width - lineWidth) / 2, 340);
  ctx.lineTo((canvas.width + lineWidth) / 2, 340);
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Teks "Sebagai"
  ctx.font = '22px Sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Sebagai', canvas.width / 2, 360);

  // Juara
  ctx.font = 'bold 32px Serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(juara.toUpperCase(), canvas.width / 2, 400);

  // Paragraf ucapan
  ctx.font = '18px Sans-serif';
  ctx.fillStyle = '#cccccc';
  ctx.fillText(`Dalam ajang bergengsi turnamen ${game},`, canvas.width / 2, 450);
  ctx.fillText(`yang telah dilaksanakan pada tanggal ${tanggal}.`, canvas.width / 2, 480);
  ctx.fillText(`Penghargaan ini diberikan sebagai bentuk apresiasi`, canvas.width / 2, 510);
  ctx.fillText(`atas semangat, dedikasi, dan prestasi yang luar biasa.`, canvas.width / 2, 540);

  // Medal
  try {
    const medal = await loadImage(medalURL);
    ctx.drawImage(medal, (canvas.width / 2) - 40, 570, 80, 80);
  } catch (err) {
    console.warn('Medal gagal dimuat:', err);
  }

  // Nama bawah
  ctx.font = 'bold 20px Sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Avery Davis', canvas.width / 3, 670);
  ctx.fillText('Bailey Dupont', (canvas.width / 3) * 2, 670);

  // Jabatan
  ctx.font = '16px Sans-serif';
  ctx.fillStyle = '#cccccc';
  ctx.fillText('Pimpinan Turnamen', canvas.width / 3, 700);
  ctx.fillText('Ketua Panitia', (canvas.width / 3) * 2, 700);

  const buffer = canvas.toBuffer('image/png');
  await conn.sendMessage(m.chat, {
    image: buffer,
    fileName: 'sertifikat.png',
    caption: `🏆 Selamat *${nama}*, kamu mendapatkan *${juara}* di turnamen *${game}*!`
  }, { quoted: m });
}

module.exports = { sendInvoice, sendGameCertificate };