/*──────────────────────────────────────────────────────────
 *  🧩 Made by NeoShiroko Labs
 *──────────────────────────────────────────────────────────
 *  🌐 Website  : https://www.neolabsofficial.my.id
 *  🌀 Panel Bot : https://pteroku-desu.zass.cloud
 *  💬 WhatsApp : https://s.id/contact-zass
 *  📺 YouTube  : https://www.youtube.com/@ZassOnee
 *
 *  [ ! ] Jangan Hapus Wm Bggg
 *──────────── © 2025 Zass Onee. All rights reserved.───────────────────
 */
const fs = require('fs');
const chalk = require('chalk');

//——————————[ Config Owner ]——————————//

global.owner = [ "6285298027445", "6288" ] // Owner tambahan 
global.ownerUtama = "6285298027445" // Ganti Nomer kamu
global.namaOwner = "Zass Need Loli" // Ganti Nama kamu
global.email = "zasscidesu@gmail.com" // Ganti email kamu

//——————————[ Config Bot ]——————————//

global.botname = 'Kuroko - Z' // Nama bot
global.versi = '2.0.0' // Version 
global.tempatDB = 'database.json' // Database

// false = nonaktif, true = aktif
global.welcome = false
global.autoread = false
global.autoreadsw = false
global.anticall = false

//——————————[ Config Sosmed ]——————————//

global.web = "https://www.neolabsofficial.my.id"
global.linkSaluran = "https://whatsapp.com/channel/0029Vb615brAzNbywHCyRc1w"
global.idSaluran = "120363417526801494@newsletter"
global.nameSaluran = "Shiroko Sync Cloud"

//——————————[ Config Sticker ]——————————//

global.packname = 'Kuroko V2'
global.author = "Zass Suka Loli"

//——————————[ Config Broadcast ]——————————//

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 5000
global.delayJpmch = 1000
global.namakontak = "AutoSave Kuroko"

//——————————[ Config Apikey ]——————————//

global.apibot2 = "https://newapibot.rikishopreal.my.id"
global.apiSimpleBot = "newapi2025"

//——————————[ Config Payment ]——————————//

//Note : Kalau gada isi aja jadi false
global.dana = "085298027445"
global.ovo = false
global.gopay = "085298027445"
global.qris = "https://telegra.ph/file/04424a604335ab88e5707.jpg"
global.an = {
    dana: "nama_dana",
    ovo: "nama_ovo",
    gopay: "nama_gopay"
}

//——————————[ Config Media ]——————————//

global.img = "https://files.catbox.moe/q6v44q.jpeg"
global.thumb =  [
    'https://files.catbox.moe/nq90d5.jpeg',
    'https://files.catbox.moe/28ujqa.jpeg',
    'https://files.catbox.moe/rj16oa.jpg',
    'https://files.catbox.moe/zqadi2.jpeg',
    'https://files.catbox.moe/02o9sw.jpeg',
    'https://files.catbox.moe/eauhwa.jpeg',
    'https://files.catbox.moe/k9qbzw.jpeg'
]
global.vn = [
    'https://i.top4top.io/m_33982amwv0.mp3',
    'https://k.top4top.io/m_3398lc27s1.mp3',
    'https://l.top4top.io/m_33987plx32.mp3',
    'https://a.top4top.io/m_3398v29sy3.mp3',
    'https://b.top4top.io/m_3398ez4xe4.mp3',
    'https://c.top4top.io/m_3398h1c6n5.mp3',
    'https://d.top4top.io/m_33984hs9e6.mp3',
    'https://e.top4top.io/m_3398xk1qb7.mp3',
    'https://f.top4top.io/m_339817znt8.mp3',
    'https://g.top4top.io/m_33985tylr9.mp3'
]

//——————————[ Config Message ]——————————//

global.mess = {
	owner: "  \`</> [ Owner Only! ]\`\n- Fitur Ini Hanya Untuk Ownerbot!",
	admin: "  \`</> [ Admin Only! ]\`\n- Fitur Ini Hanya Untuk Admin!",
	botAdmin: "  \`</> [ Bot Admin! ]\`\n- Bot Bukan Admin!",
	group: "  \`</> [ Group Only! ]\`\n- Fitur Ini Hanya Untuk Dalam Grup!",
	private: "  \`</> [ Private Only! ]\`\n- Fitur Ini Hanya Untuk Private Chat!",
	prem: "  \`</> [ Premium Only! ]\`\n- Fitur Ini Hanya Untuk Pengguna Premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

//——————————[ System ]——————————//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});