/*──────────────────────────────────────────────────────────
 *  🧩 Made by NeoShiroko Labs
 *──────────────────────────────────────────────────────────
 *  🌐 Website  : https://www.neolabsofficial.my.id
 *  🌀 Panel Bot : https://pteroku-desu.zass.cloud
 *  💬 WhatsApp : https://s.id/contact-zass
 *  📺 YouTube  : https://www.youtube.com/@ZassOnee
 *
 *  [ ! ] Jangan Hapus Wm Bggg
 *──────────── © 2025 Zass Onee. All rights reserved.───────────────────
 */
 
require('./settings');
const fs = require('fs');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require('moment-timezone');
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const path = require('path');
const gtts = require('gtts');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');

const { default: WAConnection, jidDecode, useMultiFileAuthState, Browsers, DisconnectReason, makeInMemoryStore, makeCacheableSignalKeyStore, fetchLatestWaWebVersion, proto, PHONENUMBER_MCC, getAggregateVotesInPollMessage, downloadContentFromMessage, generateWAMessageFromContent, prepareWAMessageMedia} = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./src/message');
const { TelegraPh, UguuSe } = require('./lib/uploader');
const { toAudio, toPTT, toVideo } = require('./lib/converter');
const { imageToWebp, videoToWebp, writeExif } = require('./lib/exif');
const { chatGpt, tiktokDl, facebookDl, instaDl, instaDownload, instaStory, ytMp4, ytMp3, allDl, Ytdl, cekKhodam } = require('./lib/screaper');
const { pinterest, pinterest2, wallpaper, wikimedia, quotesAnime, happymod, umma, ringtone, styletext, ssweb, igstalk, tts, remini, mediafire } = require('./lib/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, ucapan, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR} = require('./lib/function');
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const listidch = JSON.parse(fs.readFileSync("./database/listidch.json"))
const bljpm = JSON.parse(fs.readFileSync("./database/bljpm.json"))

module.exports = async (zassbtz, m, chatUpdate, store) => {
	try {
await LoadDataBase(zassbtz, m)
const botNumber = await zassbtz.decodeJid(zassbtz.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = "."
const isCmd = body.startsWith(prefix)
const time = moment.tz('Asia/Jakarta').format('HH:mm')
const from = m.key.remoteJid
const messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
var crypto = require("crypto")
let { randomBytes } = require("crypto")
const makeid = randomBytes(3).toString('hex')
const getQuoted = (m.quoted || m)
const isCreator = isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
const sender = m.key.fromMe ? (zassbtz.user.id.split(':')[0]+'@s.whatsapp.net' || zassbtz.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const groupMetadata = m.isGroup ? await zassbtz.groupMetadata(m.chat).catch(e => {}) : {}
let participant_bot = m.isGroup ? groupMetadata?.participants.find((v) => v.id == botNumber) : {}
let participant_sender = m.isGroup ? groupMetadata?.participants.find((v) => v.id == m.sender) : {}
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const func = require('./database/utils.js')

const thumbs = global.thumb
const randomThumbUrl = thumbs[Math.floor(Math.random() * thumbs.length)]
const audioList = global.vn
const audioUrl = audioList[Math.floor(Math.random() * audioList.length)]

//——————————[ Log Pesan ]——————————//

if (!m.isBaileys) {
  moment.locale('id'); // Set locale Indonesia
  const now = moment().utcOffset(7); // WIB = UTC+7
  const tanggal = now.format('dddd, D MMMM YYYY');  // contoh: Selasa, 23 April 2025
  const jam = now.format('HH.mm.ss');               // contoh: 21.59.03

  const garisAtas = chalk.hex('#33FFCC')('═'.repeat(60));
  const garisBawah = chalk.hex('#E0FFFF')('─'.repeat(60));
  const label = m.isGroup
    ? chalk.bgHex('#8A2BE2').hex('#FFFFFF').bold('💬 GROUP CHAT')
    : chalk.bgHex('#20B2AA').hex('#FFFFFF').bold('💬 PRIVATE CHAT');

  const msgType = Object.keys(m.message || {})[0];
  let isiPesan = '';
  let ikonType = '';

  switch (msgType) {
    case 'conversation':
      isiPesan = m.message.conversation;
      ikonType = '📝 Text';
      break;
    case 'extendedTextMessage':
      isiPesan = m.message.extendedTextMessage.text;
      ikonType = '📝 Text (Extended)';
      break;
    case 'imageMessage':
      isiPesan = m.message.imageMessage?.caption || '[Image]';
      ikonType = '🖼️ Image';
      break;
    case 'videoMessage':
      isiPesan = m.message.videoMessage?.caption || '[Video]';
      ikonType = '🎥 Video';
      break;
    case 'documentMessage':
      const doc = m.message.documentMessage || {};
      const fileName = doc.fileName || '[Document]';
      const mimeType = doc.mimetype || '';
      const fileSize = doc.fileLength || 0;
      const fileSizeMB = (fileSize / (1024 * 1024)).toFixed(2) + ' MB';

      isiPesan = `${fileName} (${fileSizeMB})`;

      if (mimeType.includes('zip') || fileName.toLowerCase().endsWith('.zip') || fileName.toLowerCase().endsWith('.rar')) {
        ikonType = '🗜️ Archive (ZIP/RAR)';
      } else {
        ikonType = '📄 Document';
      }
      break;
    case 'audioMessage':
      isiPesan = '[Audio]';
      ikonType = '🎵 Audio';
      break;
    case 'stickerMessage':
      isiPesan = '[Sticker]';
      ikonType = '🔖 Sticker';
      break;
    default:
      isiPesan = `[${msgType.toUpperCase()}]`;
      ikonType = '❔ Unknown';
  }

  const putih = chalk.hex('#FFFFFF');
  const terang = chalk.hex('#FFFF33');
  const hijau = chalk.hex('#00FF00').bold;
  const cyan = chalk.hex('#00FFFF');
  const pink = chalk.hex('#FF66FF');
  const abu = chalk.hex('#B0BEC5');

  let pengirim = m.sender.split('@')[0];
  let namaGroup = '';
  if (m.isGroup) {
    try {
      const metadata = await zassbtz.groupMetadata(m.chat);
      namaGroup = metadata.subject;
    } catch (e) {
      namaGroup = '[Group Tidak Dikenal]';
    }
  }

  console.log(`\n${garisAtas}`);
  console.log(label);
  console.log(`${putih('📅 Tanggal   :')} ${putih(tanggal)}`);
  console.log(`${putih('⏰ Jam       :')} ${terang(jam)}`);
  console.log(`${putih('👤 Pengirim  :')} ${cyan(pengirim)}${m.isGroup ? ` ${putih('di')} ${pink(namaGroup)}` : ''}`);
  console.log(`${putih('💬 Type Pesan:')} ${putih(ikonType)}`);
  console.log(`${putih('💬 Type Chat :')} ${m.isGroup ? 'Group' : 'Private'}`);
  if (isiPesan && !isiPesan.startsWith('[')) {
    console.log(`${putih('📝 Isi Pesan :')} ${hijau(isiPesan)}`);
  } else {
    console.log(`${putih('📝 Isi Pesan :')} ${abu(isiPesan)}`);
  }
  console.log(garisBawah);
}

//——————————[ Respons Bot ]——————————//

const reply = async (teks) => {
  const now = new Date();
  const tanggal = now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const jam = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

  const garisAtas = chalk.hex('#33FFCC')('═'.repeat(60));
  const garisBawah = chalk.hex('#E0FFFF')('─'.repeat(60));
  const putih = chalk.hex('#FFFFFF');
  const hijau = chalk.hex('#00FF00').bold;
  const terang = chalk.hex('#FFFF33');

  const label = m.isGroup
    ? chalk.bgHex('#8A2BE2').hex('#FFFFFF').bold('🤖 RESPON DI GROUP')
    : chalk.bgHex('#20B2AA').hex('#FFFFFF').bold('🤖 RESPON DI PRIVATE');

  console.log(`\n${garisAtas}`);
  console.log(label);
  console.log(`${putih('📅 Tanggal   :')} ${putih(tanggal)}`);
  console.log(`${putih('⏰ Jam       :')} ${terang(jam)}`);
  console.log(`${putih('📝 Pesan     :')} ${hijau(teks)}`);
  console.log(`${putih('💬 Type Chat :')} ${m.isGroup ? 'Group' : 'Private'}`);
  console.log(garisBawah);

  return await zassbtz.sendMessage(m.chat, {
    text: teks,
    mentions: [],
    contextInfo: {
      isForwarded: true,
      forwardingScore: 9999,
      forwardedNewsletterMessageInfo: {
        newsletterName: global.nameSaluran,
        newsletterJid: global.idSaluran
      }
    }
  }, { quoted: m });
};

//——————————[ Template quoted ]——————————//

const qkuro = { key:{ remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net' }, message:{ newsletterAdminInviteMessage: { newsletterJid: global.idSaluran, newsletterName: 'ᴠᴇʀɪғɪᴄᴀᴛɪᴏɴ', caption: `${botname} Made By ${namaOwner}`, inviteExpiration: 0}}}

const qtext = {
  key: { 
    remoteJid: "status@broadcast", 
    participant: "0@s.whatsapp.net"
  },
  message: {
    extendedTextMessage: {
      text: global.botname
    }
  }
};

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `${global.botname} by ${namaOwner}`,jpegThumbnail: ""}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `${global.botname} Made By ${namaOwner}`,jpegThumbnail: ""}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `Payment By ${namaOwner}`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${global.botname} made by ${namaOwner}`,jpegThumbnail: ""}}}

var ppuser
try {
ppuser = await zassbtz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}

//——————————[ Event Control ]——————————//

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].simi == true && !isCmd) {
try {
let res = await axios.get(`https://simsimi.site/api/v2/?mode=talk&lang=id&message=${m.text}&filter=true`)
if (res.data.success) {
await reply(res.data.success)
}
} catch (e) {}
}

//——————————[ Function ]——————————//

function isQuotedImage(message) {
    return message.quoted && message.quoted.type === 'image';
}

function isUserAllowedInServer(user, serverIndex) {
  return settingpanel[serverIndex].users.some(u => u.includes(user));
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function example(teks) {
  const textContoh = `\`\`\`</> Contoh Penggunaan :\`\`\`\nKetik *${prefix + command}* ${teks}`;
  const nedd = {
    text: textContoh,
    contextInfo: {
      mentionedJid: [m.sender],
      forwardingScore: 9999999,
      isForwarded: true,
      externalAdReply: {
        title: `- ${botname} -`,
        body: `Version ${versi}`,
        previewType: "PHOTO",
        thumbnailUrl: global.img,
        sourceUrl: web,
        showAdAttribution: true,
        containsAutoReply: true
      }
    }
  };
  return zassbtz.sendMessage(m.chat, nedd, {
    quoted: qkuro
  });
}

async function showPrivateLoading(zassbtz, m) {
  if (m.isGroup) return; // hanya berlaku di chat pribadi

  const icons = ['🕳️', '🖤', '🤎', '💜', '🕳️'];
  for (let icon of icons) {
    await zassbtz.sendMessage(m.chat, { react: { text: icon, key: m.key } }).catch(() => {});
    await new Promise(res => setTimeout(res, 500));
  }

  // Hapus reaksi terakhir
  await zassbtz.sendMessage(m.chat, { react: { text: '', key: m.key } }).catch(() => {});
}

//——————————[ Case Command ]——————————//

switch (command) {
case "menu":
case "kuroko": {
await showPrivateLoading(zassbtz, m);
let timestamp = speed();
let latensi = speed() - timestamp;
let desc = tanggal(Date.now())
const text13 = `
╭─✧ Hello *${pushname}📍*
├ 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : *${global.namaOwner}*
├ 𝐍𝐮𝐦𝐛𝐞𝐫 : *${ownerUtama}*
├ 𝐍𝐚𝐦𝐚 𝐁𝐨𝐭 : *${botname}*
├ 𝐌𝐨𝐝𝐞 : *${zassbtz.public ? 'Public' : 'Self'}*
├ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : *${runtime(process.uptime())}*
├ 𝐕𝐏𝐒 𝐔𝐩𝐭𝐢𝐦𝐞 : *${runtime(os.uptime())}*
╰─────⚙ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
╭─────────────────────➤
│╭─▣「 *Group Menu* 」▣─╮
││ ⟿ .delete
││ ⟿ .joingc
││ ⟿ .leavegc
││ ⟿ .leavegc2
││ ⟿ .welcome
│╰─➤
│
│╭─▣「 *Broadcast Menu* 」▣─╮
││ ⟿ .bljpm
││ ⟿ .cekidgc
││ ⟿ .listgc
││ ⟿ .pushkontak
││ ⟿ .pushkontak1
││ ⟿ .pushkontak2
││ ⟿ .pushkontak3
││ ⟿ .savekontak
││ ⟿ .jpm
││ ⟿ .jpmht
││ ⟿ .jpmch
│╰─➤
│
│╭─▣「 *Channel Menu* 」▣─╮
││ ⟿ .addidch
││ ⟿ .cekidch
││ ⟿ .delidch
││ ⟿ .listidch
││ ⟿ .upch
││ ⟿ .reactch
│╰─➤
│
│╭─▣「 *Sticker Menu* 」▣─╮
││ ⟿ .brat
││ ⟿ .sticker
│╰─➤
│
│╭─▣「 *Tools Menu* 」▣─╮
││ ⟿ .tohd
││ ⟿ .tourl
││ ⟿ .tts
││ ⟿ .rvo
││ ⟿ .vo
││ ⟿ .getpp
││ ⟿ .toimg
│╰─➤
│
│╭─▣「 *Control Menu* 」▣─╮
││ ⟿ .setppbot
││ ⟿ .setnamabot
││ ⟿ .setbiobot
││ ⟿ .setting
││ ⟿ .autoread
││ ⟿ .autoreadsw
││ ⟿ .anticall
││ ⟿ .restart
││ ⟿ .owner
│╰─➤
│
│╭─▣「 *Store Menu* 」▣─╮
││ ⟿ .proses
││ ⟿ .done
││ ⟿ .dana
││ ⟿ .ovo
││ ⟿ .gopay
││ ⟿ .qris
││ ⟿ .tambah
││ ⟿ .kurang
││ ⟿ .kali
││ ⟿ .bagi
││ ⟿ .feeadmin
││ ⟿ .formatned
││ ⟿ .formatjp
││ ⟿ .allrec
│╰─➤
│
│╭─▣「 *Downloader Menu* 」▣─╮
││ ⟿ .tiktok
││ ⟿ .tiktokmp3
││ ⟿ .instagram
││ ⟿ .videy
││ ⟿ .xnxx
││ ⟿ .ytmp3
││ ⟿ .ytmp4
│╰─➤
│
│╭==⊱ *Source Script* ▣─╮
││㉿ YouTube: youtube.com/@ZassOnee
││㉿ Website: ${global.web}
│╰───➤
╰─────┈➤

    ⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕
  『 *© 2025 NeoShiroko Labs* 』
`;
  await zassbtz.sendMessage(m.chat, {
    text: text13,
    mentions: [m.sender, global.owner + "@s.whatsapp.net"],
    contextInfo: {
      forwardingScore: 999999,
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      externalAdReply: {
        title: `${botname} Version ${versi}`,
        body: desc,
        thumbnailUrl: randomThumbUrl,
        mediaType: 1,
        renderLargerThumbnail: true,
        showAdAttribution: false
      }
    }
  }, { quoted: qkuro })

  await zassbtz.sendMessage(m.chat, {
    audio: { url: audioUrl },
    mimetype: 'audio/mp4',
    ptt: true
  }, { quoted: qkuro })
}
break;

//————————————————————//

case "pushkontak":
    if (!isCreator) return reply(mess.owner);
    if (!m.isGroup) return reply(mess.group);
    if (!text) return reply(`Penggunaan Salah! Gunakan perintah seperti ini:\n${prefix + command} jeda|teks`);

    await showPrivateLoading(zassbtz, m);
    await reply(`Memproses *push kontak*`);

    const data = await zassbtz.groupMetadata(m.chat);
    const halsss = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);

    global.tekspushkonv4 = text.split("|")[1];

    let media = null;
    if (m.quoted && /image/.test(m.quoted.mimetype)) {
        media = await zassbtz.downloadAndSaveMediaMessage(m.quoted);
    }

    for (let men of halsss) {
        let message;

        if (media) {
            message = {
                image: fs.readFileSync(media), // langsung baca file buffer
                caption: global.tekspushkonv4,
                mentions: [men],
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 9999,
                    mentionedJid: [men],
                    forwardedNewsletterMessageInfo: {
                        newsletterName: global.nameSaluran,
                        newsletterJid: global.idSaluran
                    }
                }
            };
        } else {
            message = {
                text: global.tekspushkonv4,
                mentions: [men],
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 9999,
                    mentionedJid: [men],
                    forwardedNewsletterMessageInfo: {
                        newsletterName: global.nameSaluran,
                        newsletterJid: global.idSaluran
                    }
                }
            };
        }

        await zassbtz.sendMessage(men, message);
        await sleep(parseInt(text.split("|")[0]));
    }
reply(`*Push Kontak Berhasil ✅*\n*Total member*: ${halsss.length} berhasil dikirim pesan`);
break;

//————————————————————//

case "pushkontak1": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("idgc|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
await showPrivateLoading(zassbtz, m);
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await zassbtz.groupMetadata(`${idnya}`)
} catch (e) {
return reply(`*❌ Invalid Group ID!*

Silakan periksa kembali dan coba lagi.

–––––––––––––––––
> ${namaOwner} © 2025`)
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
const contactName = global.namakontak || "FRESH KONTAK";
await reply(`*⌛ Sedang Memproses...*

• Status: Mengirim pesan
• Jumlah kontak: *${halls.length}*

────────────
> ${namaOwner} © 2025`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await zassbtz.sendMessage(mem, {text: teks}, {quoted: qloc})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
let counter = 1;

const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
counter++;
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`*✅ Kontak Berhasil Dikirim!*

• Lokasi: *Chat Pribadi Anda*  
• Jumlah Kontak: *${halls.length}*

────────────────────
> ${namaOwner} © 2025`)
await zassbtz.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `*Kontak Siap Digunakan! ✅*

• Jumlah File: *${halls.length} kontak*  
• Status: *Berhasil dibuat*

──────────────
> ${namaOwner} © 2025`, mimetype: "text/vcard", }, { quoted: qloc })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break

//————————————————————//

case "pushkontak2": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
await showPrivateLoading(zassbtz, m);
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return reply(`*❌ Invalid Group ID!*

Periksa kembali dan coba lagi.

──────────────
> ${namaOwner} © 2025`)
if (isNaN(delay)) return reply(`❌ *Format Delay Tidak Valid!*

⏱️ Gunakan format delay yang benar, lalu coba lagi.

────────────────────
> ${namaOwner} © 2025`)
if (!teks) return reply(`*📌 Contoh Penggunaan:*
.pushkontak2 idgc|jeda|pesan

*ℹ️ Catatan:*
Jeda 1 detik = 1000 (ms)

Ketik *.listgc* untuk melihat daftar ID grup yang tersedia.`)
var groupMetadataa
try {
groupMetadataa = await zassbtz.groupMetadata(`${idnya}`)
} catch (e) {
return reply(`*❌ ID Grup Tidak Valid!*
Silakan periksa kembali dan coba lagi.

> ${namaOwner} © 2025`)
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
const contactName = global.namakontak || "FRESH KONTAK";
await reply(`⏳ Sedang Mengirim Pesan...

📤 Mengirim ke *${halls.length} kontak*...

> ${namaOwner} © 2025`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await zassbtz.sendMessage(mem, {text: teks}, {quoted: qloc})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
let counter = 1;

const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
counter++;
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`*Berhasil Mendorong Kontak! ✅*

• Jumlah File: *${halls.length} kontak*  
• Status: *Terkirim ke obrolan pribadi*

──────────────
> ${namaOwner} © 2025`)
await zassbtz.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `✅ *Contact File Created Successfully!*

• Jumlah: *${halls.length} Kontak*

──────────────
> ${namaOwner} © 2025`, mimetype: "text/vcard", }, { quoted: qloc })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break

//————————————————————//

case "pushkontak3": {
if (!isCreator) return reply(mess.owner)

// Memeriksa format perintah
if (!text) return reply(example("idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
await showPrivateLoading(zassbtz, m);

var idnya = text.split("|")[0]         // ID grup
var delay = Number(text.split("|")[1]) // Jeda
var contactName = text.split("|")[2]   // Nama kontak
var teks = text.split("|")[3]          // Pesan yang dikirim

// Memeriksa format dan validasi input
if (!idnya.endsWith("@g.us")) return reply(`*❌ Invalid Group ID!*

• Periksa ID dan coba lagi.

──────────────
> ${namaOwner} © 2025`)
if (isNaN(delay)) return reply(`*❌ Invalid Delay Format!*

• Gunakan format yang benar dan coba lagi.

──────────────
> ${namaOwner} © 2025`)
if (!contactName || !teks) return reply(`*Contoh Command:*
.pushkontak3 idgc | jeda | namakontak | pesan

*Note:*
• Jeda 1 detik = 1000
• Ketik *.listgc* untuk melihat semua list ID grup`)

var groupMetadataa
try {
groupMetadataa = await zassbtz.groupMetadata(`${idnya}`)
} catch (e) {
return reply(`*❌ Invalid Group ID!*

• Periksa ID dan coba lagi.

──────────────
> ${namaOwner} © 2025`)
}

const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)

// Mengirimkan notifikasi ke owner
await reply(`*⌛ Memproses Pengiriman Pesan.*

• Mengirim pesan ke *${halls.length} kontak*...

──────────────
> ${namaOwner} © 2025`)

// Mengirim pesan ke setiap kontak
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await zassbtz.sendMessage(mem, { text: teks }, { quoted: qloc })
await sleep(Number(delay))
}
}

try {
// Membuat file vCard dengan nama yang diberikan oleh user
const uniqueContacts = [...new Set(contacts)]
let counter = 1;

const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${contactName} ${counter}`, // Menggunakan nama kontak dari input user
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"",
].join("\n")
counter++;
return vcard
}).join("")

fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
return reply(err.toString())
} finally {
// Mengirimkan hasil ke pengguna
if (m.chat !== m.sender) await reply(`*Berhasil Mendorong Kontak! ✅*

• File kontak telah dikirim ke obrolan pribadi Anda
• Total: ${halls.length} Kontak
• Nama Kontak: ${contactName}

──────────────
> ${namaOwner} © 2025`)

await zassbtz.sendMessage(
m.sender,
{
document: fs.readFileSync("./database/contacts.vcf"),
fileName: "contacts.vcf",
caption: `✅ *File Kontak Berhasil Dibuat!*

• Total: *${halls.length}* Kontak
• Nama Kontak: ${contactName}

──────────────
> ${namaOwner} © 2025`,
mimetype: "text/vcard",
},
{ quoted: qloc }
)

// Reset kontak dan file setelah selesai
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}
}
break

//————————————————————//

case "savekontak": {
    if (!isCreator) return reply(mess.owner)

    if (!text.includes("|")) {
        return reply(`❌ *Format Salah!*\nGunakan format:\n.savekontak idgc|namakontak\n\n────────────────────\n> ${namaOwner} © 2025`)
    }

    await showPrivateLoading(zassbtz, m)

    const [idgc, namaKontak] = text.split("|").map(v => v.trim())
    if (!idgc || !namaKontak) {
        return reply(`❌ *Input Tidak Lengkap!*\nPastikan ID grup dan nama kontak diisi.\n\n────────────────────\n> ${namaOwner} © 2025`)
    }

    let metadata
    try {
        metadata = await zassbtz.groupMetadata(idgc)
    } catch (e) {
        return reply(`❌ *ID Grup Tidak Valid!*\nPeriksa kembali dan coba lagi.\n\n────────────────────\n> ${namaOwner} © 2025`)
    }

    const semuaAnggota = metadata.participants
    const targetKontak = semuaAnggota.filter(v => v.id.endsWith(".net")).map(v => v.id)

    // Simpan semua kontak unik ke file
    for (const kontak of targetKontak) {
        if (kontak !== m.sender && !contacts.includes(kontak)) {
            contacts.push(kontak)
            fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
        }
    }

    try {
        const unik = [...new Set(contacts)]
        let no = 1
        const isiVCF = unik.map(contact => {
            return [
                "BEGIN:VCARD",
                "VERSION:3.0",
                `FN:${namaKontak} ${no++}`,
                `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
                "END:VCARD", ""
            ].join("\n")
        }).join("")

        fs.writeFileSync("./database/contacts.vcf", isiVCF, "utf8")
    } catch (err) {
        return reply(`❌ *Gagal Membuat File Kontak:*\n${err}`)
    } finally {
        if (m.chat !== m.sender) {
            await reply(`
✅ *Kontak Berhasil Disimpan!*
📂 File kontak telah dikirim ke obrolan pribadi Anda.
👤 Nama Kontak: *${namaKontak}*
📊 Total: *${targetKontak.length}* Kontak

────────────────────
> ${namaOwner} © 2025`)
        }

        await zassbtz.sendMessage(
            m.sender,
            {
                document: fs.readFileSync("./database/contacts.vcf"),
                fileName: "contacts.vcf",
                caption: `✅ *File Kontak Siap Digunakan!*\n📁 Total: *${targetKontak.length}* Kontak\n👤 Nama: *${namaKontak}*\n\n────────────────────\n> ${namaOwner} © 2025`,
                mimetype: "text/vcard"
            },
            { quoted: qloc }
        )

        // Reset kontak
        contacts.splice(0, contacts.length)
        fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
        fs.writeFileSync("./database/contacts.vcf", "")
    }
}
break

//————————————————————//

case "b": case "blacklistjpm": case "bljpm": {
if (!isCreator) return m.reply(mess.owner)
if (!m.isGroup) return m.reply(mess.group)
if (!text) return example("on/off")
let teks = text.toLowerCase()
if (teks == "on") {
if (bljpm.includes(m.chat)) return m.reply(`*Blacklistjpm* di grup ini sudah aktif!`)
bljpm.push(m.chat)
await fs.writeFileSync('./database/bljpm.json', JSON.stringify(bljpm))
return m.reply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (!bljpm.includes(m.chat)) return m.reply(`*Blacklistjpm* di grup ini tidak aktif!`)
let posi = bljpm.indexOf(m.chat)
bljpm.splice(posi, 1)
await fs.writeFileSync('./database/bljpm.json', JSON.stringify(bljpm))
return m.reply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return example("on/off")
}
break

//————————————————————//

case "jpm": {
  if (!isCreator) return reply(mess.owner)
  if (!text) return example(`Halo semua!\nKirim foto dengan caption (opsional)`)

  let mediaPath
  if (/image/.test(mime)) {
    mediaPath = await zassbtz.downloadAndSaveMediaMessage(qmsg)
  }

  const allGroups = await zassbtz.groupFetchAllParticipating()
  const groupIDs = Object.keys(allGroups)
  let sentCount = 0

  const broadcastMsg = mediaPath
    ? { image: fs.readFileSync(mediaPath), caption: text }
    : { text }

  await m.reply(`*⏳ Memproses jpm...*\nJumlah grup: ${groupIDs.length}\nTipe: ${mediaPath ? "Teks + Foto" : "Teks"}`)

  for (const id of groupIDs) {
    if (bljpm.includes(id)) continue // Skip grup yang diblacklist

    try {
      await zassbtz.sendMessage(id, broadcastMsg, { quoted: qlocJpm })
      sentCount++
    } catch {}
    
    await sleep(global.delayJpm || 4000)
  }

  if (mediaPath) fs.unlinkSync(mediaPath)

  await zassbtz.sendMessage(m.chat, {
    text: `*✅ Jpm Selesai!*\nBerhasil terkirim ke *${sentCount}* grup dari total ${groupIDs.length}.`,
  }, { quoted: m })
}
break

//————————————————————//

case "jpmht": {
  if (!isCreator) return reply(mess.owner)
  if (!text) return example(`teks dan foto (opsional)`)

  let mediaPath
  if (/image/.test(mime)) {
    mediaPath = await zassbtz.downloadAndSaveMediaMessage(m)
  } else if (m.quoted && /image/.test(m.quoted.mtype)) {
    mediaPath = await zassbtz.downloadAndSaveMediaMessage(m.quoted)
  }

  const allGroups = await zassbtz.groupFetchAllParticipating()
  const groupIDs = Object.keys(allGroups)
  let sentCount = 0

  await m.reply(`*⏳ Memproses hide-tag broadcast...*\nTotal grup: ${groupIDs.length}\nMengecualikan grup blacklist...`)

  for (const id of groupIDs) {
    if (bljpm.includes(id)) continue

    try {
      const metadata = await zassbtz.groupMetadata(id)
      const participants = metadata.participants.map(p => p.id)

      const msgContent = mediaPath
        ? { image: fs.readFileSync(mediaPath), caption: text, mentions: participants }
        : { text: text, mentions: participants }

      await zassbtz.sendMessage(id, msgContent, { quoted: qlocJpm })
      sentCount++
    } catch {}

    await sleep(global.delayJpm || 4000)
  }

  if (mediaPath) fs.unlinkSync(mediaPath)

  await zassbtz.sendMessage(m.chat, {
    text: `*✅ Hide-tag Broadcast Selesai!*\nBerhasil terkirim ke *${sentCount}* grup.`,
  }, { quoted: m })
}
break

//————————————————————//

case "jpmch": case "jpmallch": {
if (!isCreator) return reply(mess.owner)
if (listidch.length < 1) return reply("Tidak ada id ch didalam database")
if (!q) return reply(example("teksnya bisa dengan kirim foto juga"))
let rest
if (/image/.test(mime)) {
rest = await zassbtz.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = listidch
const res = allgrup
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const opsijpm = rest !== undefined ? "teks & foto" : "teks"
const jid = m.chat
await reply(`Memproses jpmch *${opsijpm}* ke ${res.length} channel`)
for (let i of res) {
try {
await zassbtz.sendMessage(i, pesancoy)
count += 1
} catch {}
await sleep(global.delayJpmch)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await zassbtz.sendMessage(jid, {text: `Jpmch *${opsijpm}* berhasil dikirim ke ${count} channel`}, {quoted: m})
}
break

//————————————————————//

case 'listgc':
case 'listgrup': {
  if (!isCreator) return reply(mess.owner);
  
  await zassbtz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } });

  let gcall;
  try {
    gcall = Object.values(await zassbtz.groupFetchAllParticipating());
  } catch (e) {
    return m.reply("*✖️ Gagal mengambil daftar grup.*");
  }

  let teks = `*📦 Daftar Grup Terkait (${gcall.length} Grup):*\n\n`;
  gcall.forEach((group, index) => {
    teks += `*${index + 1}. ${group.subject}*\n`;
    teks += `├ ID: ${group.id}\n`;
    teks += `├ Member: ${group.participants.length}\n`;
    teks += `├ Status: ${group.announce ? "🔒 Tertutup" : "🔓 Terbuka"}\n`;
    teks += `└ Pembuat: ${group.owner ? "@" + group.owner.split('@')[0] : '✖️ Tidak Diketahui'}\n\n`;
  });

  zassbtz.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: `📁 ${gcall.length} Grup Aktif`,
        body: `🧩 List Group`,
        sourceUrl: global.web,
        thumbnail: await getBuffer(randomThumbUrl),
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: qkuro });
}
break;

//————————————————————//

case 'cekidgc': case 'getidgrup': {
if (!isCreator) return reply(mess.owner)
if (!q) return example(`link grupnya`)
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return m.reply("Link Invalid")
zassbtz.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
let tekse = `${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}`
m.reply(tekse)
})}
break;

//————————————————————//

case "tiktok": case "tt": {
if (!text) return reply(example("linknya"))
await showPrivateLoading(zassbtz, m);
var anu = await func.fetchJson(`https://newapibot.rikishopreal.my.id/download/tiktok?apikey=newapi2025&url=${text}`)
if (anu.status) {
if (anu.result.slides.length > 1) {
for (let i of anu.result.slides) {
await zassbtz.sendFileUrl(m.chat, i.url, "Tiktok Download Done ✅", m)
}
} else {
await zassbtz.sendMessage(m.chat, {video: {url: anu.result.video_nowm}, caption: "Tiktok Download Done ✅", mimetype: "video/mp4"}, {quoted: m})
}
await zassbtz.sendMessage(m.chat, {audio: {url: anu.result.audio_url}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return reply("Error! Result Not Found")
}
}
break;

//————————————————————//

case "del":
case "delete": {
  if (!isCreator) return reply(mess.owner);
  if (!m.quoted) return m.reply("Reply pesan yang ingin dihapus");

  const isGroup = m.isGroup;
  const botNumberJid = zassbtz.user.id.split(':')[0] + '@s.whatsapp.net';

  const groupMetadata = isGroup ? await zassbtz.groupMetadata(m.chat) : {};
  const groupAdmins = isGroup ? groupMetadata.participants.filter(p => p.admin !== null).map(p => p.id) : [];

  const isBotAdmin = isGroup ? groupAdmins.includes(botNumberJid) : false;
  const senderIsBot = m.quoted.sender === botNumberJid;
  const fromMe = senderIsBot;

  if (isGroup && !isBotAdmin) {
    return m.reply("Bot harus admin untuk menghapus pesan di grup!");
  }

  zassbtz.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe,
      id: m.quoted.id,
      participant: m.quoted.sender
    }
  });
}
break;

//————————————————————//

case "joingc": case "join": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return example('linknya')
let teks = m.quoted ? m.quoted.text : text
if (!teks.includes('whatsapp.com')) return m.reply("Link Tautan Tidak Valid!")
let result = teks.split('https://chat.whatsapp.com/')[1]
await zassbtz.groupAcceptInvite(result).then(respon => m.reply("Berhasil Bergabung Ke Dalam Grup ✅")).catch(error => m.reply(error.toString()))
}
break;

//————————————————————//

case "leave": case "leavegc": {
if (!isCreator) return reply(mess.owner)
if (!isGroup) return m.reply(msg.group)
await m.reply("Otw Bosss")
await sleep(3000)
await zassbtz.groupLeave(m.chat)
}
break;

//————————————————————//

case "leavegc2": case "leave2": {
if (!isCreator) return reply(mess.owner)
let gcall = await Object.values(await zassbtz.groupFetchAllParticipating().catch(_=> null))
let num = []
let listgc = `*Contoh Cara Penggunaan :*\nKetik *${cmd}* Nomor Grup\n\n`
await gcall.forEach((u, i) => {
num.push(i)
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
if (!args[0]) {
zassbtz.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `[ ${gcall.length} Group Chat ] `, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.linkyt, previewType: "PHOTO"}}}, {quoted: qchanel})
} else if (args[0]) {
if (!num.includes(Number(args[0]) - 1)) return m.reply("Grup tidak ditemukan")
let leav = Number(args[0]) - 1
await m.reply(`Berhasil Keluar Dari Grup :\n*${gcall[leav].subject}*`)
await zassbtz.groupLeave(`${gcall[leav].id}`)
}}
break;

//————————————————————//

case "tiktokmp3": case "ttmp3": {
if (!isCreator) return reply(mess.prem)
if (!text) return reply(example("linknya"))
await showPrivateLoading(zassbtz, m);
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await tiktokDl(text).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await zassbtz.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await zassbtz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => reply("Error! Result Not Found"))
}
break;

//————————————————————//

case "instagram": case "ig": {
if (!text) return reply(example("linknya"))
reply("📥 Memproses instagram downloader . .")
var anu = await func.fetchJson(`https://newapibot.rikishopreal.my.id/download/instagram?apikey=newapi2025&url=${text}`)
if (anu.status) {
for (let i of anu.result.downloadUrls) {
await zassbtz.sendFileUrl(m.chat, i, "Instagram Download Done ✅", m)
}
} else {
return reply("Error! Result Not Found")
}
}
break

//————————————————————//

case "reactch":
case "rch": {
  if (!isCreator) return reply(mess.owner);
  if (!text) return reply("Contoh:\n.reactch https://whatsapp.com/channel/xxx/123 ❤️ mamix\n.reactch https://whatsapp.com/channel/xxx/123 ❤️mamix|5");

  const hurufGaya = {
    a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
    h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
    o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
    v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
    '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
    '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
  };

  const [mainText, offsetStr] = text.split('|');
  const args = mainText.trim().split(" ");
  const link = args[0]?.trim();

  const match = link.match(/https:\/\/whatsapp\.com\/channel\/([a-zA-Z0-9_-]+)\/(\d+)/);
  if (!match) return reply("❌ Link tidak valid!\nContoh: .reactch https://whatsapp.com/channel/xxx/123 ❤️mamix|3");

  const channelId = match[1];
  const rawMessageId = match[2];

  const offset = parseInt(offsetStr?.trim()) || 1;
  const teksTanpaLink = args.slice(1).join(' ');
  if (!teksTanpaLink) return reply("Masukkan teks/emoji untuk direaksikan.");

  const emoji = teksTanpaLink.toLowerCase().split('').map(c => {
    if (c === ' ') return '―';
    return hurufGaya[c] || c;
  }).join('');

  try {
    const metadata = await zassbtz.newsletterMetadata("invite", channelId);
    let success = 0, failed = 0;

    for (let i = 0; i < offset; i++) {
      const msgId = (parseInt(rawMessageId) - i).toString();
      try {
        await zassbtz.newsletterReactMessage(metadata.id, msgId, emoji);
        success++;
      } catch (e) {
        failed++;
      }
    }

    reply(`✅ Berhasil kirim reaction *${emoji}* ke ${success} pesan di channel *${metadata.name}*\n❌ Gagal di ${failed} pesan`);
  } catch (err) {
    console.error(err);
    reply("❌ Gagal memproses permintaan!");
  }
}
break;

//————————————————————//

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
var image = await zassbtz.downloadAndSaveMediaMessage(qmsg)
await zassbtz.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break;

//————————————————————//

case 'brat': {
const { createCanvas, registerFont } = require('canvas');
const Jimp = require('jimp');
async function BratGenerator(teks) {
  let width = 512;
  let height = 512;
  let margin = 20;
  let wordSpacing = 50; 
  let canvas = createCanvas(width, height);
  let ctx = canvas.getContext('2d');
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, width, height);
  let fontSize = 280;
  let lineHeightMultiplier = 1.3;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle = 'black';
registerFont('./lib/arialnarrow.ttf', { family: 'Narrow' });
  let words = teks.split(' ');
  let lines = [];
  let rebuildLines = () => {
    lines = [];
    let currentLine = '';
    for (let word of words) {
      let testLine = currentLine ? `${currentLine} ${word}` : word;
      let lineWidth =
        ctx.measureText(testLine).width + (currentLine.split(' ').length - 1) * wordSpacing;
      if (lineWidth < width - 2 * margin) {
        currentLine = testLine;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    if (currentLine) {
      lines.push(currentLine);
    }
  };
  ctx.font = `${fontSize}px Narrow`;
  rebuildLines();
  while (lines.length * fontSize * lineHeightMultiplier > height - 2 * margin) {
    fontSize -= 2;
    ctx.font = `${fontSize}px Narrow`;
    rebuildLines();
  }
    let lineHeight = fontSize * lineHeightMultiplier;
  let y = margin;
  for (let line of lines) {
    let wordsInLine = line.split(' ');
    let x = margin;
    for (let word of wordsInLine) {
      ctx.fillText(word, x, y);
      x += ctx.measureText(word).width + wordSpacing;
    }
    y += lineHeight;
  }
  let buffer = canvas.toBuffer('image/png');
  let image = await Jimp.read(buffer);
  image.blur(3);
  let blurredBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
return zassbtz.sendAsSticker(m.chat, blurredBuffer, m, { packname: global.packname, author: global.author })
}
if (!text) return reply(`Masukkan teks untuk stiker.\n\nContoh:\n.brat Atmin Ganteng`);
return BratGenerator(text)
}
break;

//————————————————————//

case "viewonce": case "vo": {
 if (!m.quoted) return reply("Reply pesan media yang mau dijadiin 1x lihat (View Once).")
 let msg = m.quoted.message
 let type = Object.keys(msg)[0]

 if (msg[type].viewOnce) return reply("Itu udah 1x lihat bro.")

 let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }

 if (/image/.test(type)) {
 return zassbtz.sendMessage(m.chat, {
 image: buffer,
 caption: msg[type]?.caption || "",
 viewOnce: true
 }, { quoted: m })
 } else if (/video/.test(type)) {
 return zassbtz.sendMessage(m.chat, {
 video: buffer,
 caption: msg[type]?.caption || "",
 viewOnce: true
 }, { quoted: m })
 } else {
 return reply("Cuma bisa foto/video doang ya untuk dijadiin View Once.")
 }
}
break;

//————————————————————//

case "rvo": case "readviewonce": {
if (!m.quoted) return reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return reply("Pesan itu bukan viewonce!")
    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return zassbtz.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return zassbtz.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return zassbtz.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break;

//————————————————————//

case "tohd": case "hd": {
if (!isCreator) return reply(mess.prem)
await showPrivateLoading(zassbtz, m);
if (!/image/.test(mime)) return reply(example("dengan kirim/reply foto"))
let foto = await zassbtz.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await zassbtz.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break;

//————————————————————//

case "tts": {
if (!text) return reply(example("Hallo saya manusia"))
if (text.length >= 300) return reply("Jumlah huruf harus di bawah 300!")
reply(mess.wait)
let id = 'id_001'
try {
const { data } = await axios.post("https://tiktok-tts.weilnet.workers.dev/api/generation", {
    "text": text,
    "voice": id
})
zassbtz.sendMessage(m.chat, { audio: Buffer.from(data.data, "base64"), mimetype: "audio/mp4" }, {quoted: m})
} catch (e) {
return reply(e.toString())
}
}
break;

//————————————————————//

case "tourl": {
if (!/image|video/.test(mime)) return reply(example("dengan kirim/reply foto"))
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
async function getUrls (buffer) {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}
let media = await zassbtz.downloadAndSaveMediaMessage(qmsg)
let teks = await getUrls(fs.readFileSync(media))
await zassbtz.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break;

//————————————————————//

case "toimg": {
if (!/webp/.test(mime) && !/audio/.test(mime)) return reply(example('dengan reply sticker'))
await showPrivateLoading(zassbtz, m);
let media = await zassbtz.downloadAndSaveMediaMessage(qmsg)
let ran = `${makeid}.png`
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return err
let buffer = fs.readFileSync(ran)
zassbtz.sendMessage(m.chat, {image: buffer}, {
quoted: m})
fs.unlinkSync(ran)
})
}
break;

//————————————————————//

case "joingc": case "join": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await zassbtz.groupAcceptInvite(result)
reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break;

//————————————————————//

case 'tambah':{
if (!text.includes('+')) return reply(`Gunakan dengan cara ${prefix+command} *angka* + *angka*\n\n_Contoh_\n\n${prefix+command} 1+2`)
arg = args.join(' ')
atas = arg.split('+')[0]
bawah = arg.split('+')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one + nilai_two}`)}
break;

//————————————————————//

case 'kurang':{
if (!text.includes('-')) return reply(`Gunakan dengan cara ${prefix+command} *angka* - *angka*\n\n_Contoh_\n\n${prefix+command} 1-2`)
arg = args.join(' ')
atas = arg.split('-')[0]
bawah = arg.split('-')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one - nilai_two}`)}
break;

//————————————————————//

case 'kali':{
if (!text.includes('x')) return reply(`Gunakan dengan cara ${prefix+command} *angka* x *angka*\n\n_Contoh_\n\n${prefix+command} 1x2`)
arg = args.join(' ')
atas = arg.split('x')[0]
bawah = arg.split('x')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one * nilai_two}`)}
break;

//————————————————————//

case 'bagi':{
if (!text.includes('/')) return reply(`Gunakan dengan cara ${prefix+command} *angka* / *angka*\n\n_Contoh_\n\n${prefix+command} 1/2`)
arg = args.join(' ')
atas = arg.split('/')[0]
bawah = arg.split('/')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one / nilai_two}`)}
break;

//————————————————————//

case "proses": {
let desc = tanggal(Date.now())
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("jasa install panel"))
const msg = {
text: `*Dana Masuk ✅*

barang : ${text}
hari/tgl : ${desc}
status : proses ⏳

\`CATATAN\`
* pesanan anda siap kami proses 
* silahkan tunggu terimakasih 

_*© 2025 - ${namaOwner}*_`
}
await zassbtz.sendMessage(m.chat, msg, {quoted: null})
}
break;

//————————————————————//

case "done": {
let desc = tanggal(Date.now())
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("jasa install panel"))
const msg = {
text: `───◆⧽ *${namaOwner}* ⧼◆───
━━━━━━━━━━━━━━━
*ALHAMDULILLAH TRX DONE✅*
━━━━━━━━━━━━━━━
*📦 BARANG :* ${text}
*🗓️ TANGGAL :* ${desc}
*☎️ SOSMED : ${web}*

  \`JANGAN LUPA MAMPIR 👆\`
*▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬*
*TERIMAKASIH TELAH ORDER DI ${namaOwner}*
*SEMOGA SUKA DENGAN PRODUK YANG*
*KAMI SEDIAKAN DAN JADI LANGGANAN 😇*
`
}
await zassbtz.sendMessage(m.chat, msg, {quoted: null})
}
break;

//————————————————————//

case "addidch": case "addch": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("idchnya"))
if (!text.endsWith("@newsletter")) return reply("Id channel tidak valid")
let input = text
if (listidch.includes(input)) return reply(`Id ${input} sudah terdaftar!`)
listidch.push(input)
await fs.writeFileSync("./database/listidch.json", JSON.stringify(listidch, null, 2))
reply(`Berhasil menambah id channel kedalam database ✅`)
}
break;

//————————————————————//

case "delidch": case "delch": {
if (!isCreator) return reply(mess.owner)
if (listidch.length < 1) return reply("Tidak ada id channel di database")
if (!text) return reply(example("idchnya"))
if (text.toLowerCase() == "all") {
listidch.splice(0, listidch.length)
await fs.writeFileSync("./database/listidch.json", JSON.stringify(listidch))
return reply(`Berhasil menghapus semua id channel dari database ✅`)
}
if (!text.endsWith("@newsletter")) return reply("Id channel tidak valid")
let input = text
if (!listidch.includes(input)) return reply(`Id ${input} tidak terdaftar!`)
const pos = listidch.indexOf(input)
listidch.splice(pos, 1)
await fs.writeFileSync("./database/listidch.json", JSON.stringify(listidch, null, 2))
reply(`Berhasil menghapus id channel dari database ✅`)
}
break;

//————————————————————//

case "listidch": case "listch": {
if (listidch.length < 1) return reply("Tidak ada id channel di database")
let teks = ` *── List all id channel*\n`
for (let i of listidch) {
teks += `\n* ${i}\n`
}
zassbtz.sendMessage(m.chat, {text: teks, mentions: reseller}, {quoted: m})
}
break;

//————————————————————//

case "cekidch": case "idch": {
if (!text) return reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await zassbtz.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return reply(teks)
}
break;

//————————————————————//

case 'getpp':{
  if (!isCreator) {
    return reply(`✨ Cara Penggunaan yang Elegan ✨

Untuk mengambil foto profil seseorang:
1. Balas/reply pesan orang yang ingin Anda ambil fotonya
2. Ketik ${prefix}getpp

Contoh: 
> *User A mengirim pesan*
> *Anda membalas pesan User A dengan:* ${prefix}getpp

Mari kita jelajahi keindahan profil bersama! 📸✨`)
  }
  
  try {
    pporg = await zassbtz.profilePictureUrl(m.quoted.sender, 'image')
  } catch {
    pporg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
  }
  zassbtz.sendMessage(m.chat, { image : { url : pporg }, caption:`✨ ${pushname}! Inilah potret digital yang Anda cari.\nSemoga keindahannya memenuhi ekspektasi Anda! 📸🌟` }, {quoted : m})
}
break;

//————————————————————//

case "dana": {
if (global.dana == false) return m.reply('Payment Dana Tidak Tersedia')
let teks = `
*Nomor Dana :*
${dana}
*A/N :* ${an.dana}

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
await zassbtz.sendText(m.chat, teks, qtoko)
}
break;

//————————————————————//

case "ovo": {
if (global.ovo == false) return m.reply('Payment Ovo Tidak Tersedia')
let teks = `
*Nomor Ovo :*
${ovo}
*A/N :* ${an.ovo}

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
await zassbtz.sendText(m.chat, teks, qtoko )
}
break;

//————————————————————//

case "gopay": {
if (global.gopay == false) return m.reply('Payment Gopay Tidak Tersedia')
let teks = `
*Nomor Gopay :*
${gopay}
*A/N :* ${an.gopay}

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
await zassbtz.sendText(m.chat, teks, qtoko )
}
break;

//————————————————————//

case "qris": {
  if (!global.qris) return m.reply('Payment QRIS Tidak Tersedia')
  m.reply('Memproses Mengambil QRIS, Tunggu Sebentar . . .')

  let teks = `
*Untuk Pembayaran Melalui QRIS All Payment, Silahkan Scan Foto QRIS Diatas Ini*
_WAJIB TAMBAH 500P KALAU PAKAI QRIS_
*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
  `.trim()

await zassbtz.sendMessage(
    m.chat,
    {
      image: { url: global.qris }, // penting: bungkus dengan { url: ... }
      caption: teks
    },
    { quoted: qtoko }
  )
}
break;

//————————————————————// 

case 'owner': {
  const kontakUtama = {
    displayName: `Owner ${botname}`,
    vcard: `BEGIN:VCARD
VERSION:3.0
N:;;;; 
FN:${global.namaOwner}
item1.TEL;waid=6285298027445:6285298027445
item1.X-ABLabel:Developer
item2.TEL;waid=${global.ownerUtama}:${global.ownerUtama}
item2.X-ABLabel:My Owner
EMAIL;type=INTERNET:${email}
ORG:Owner ${botname}
END:VCARD`
  }
  await zassbtz.sendMessage(from, {
    contacts: { contacts: [kontakUtama] },
    contextInfo: {
      forwardingScore: 999,
      isForwarded: false,
      mentionedJid: [sender],
      externalAdReply: {
        showAdAttribution: true,
        renderLargerThumbnail: true,
        title: `${botname} - Core`,
        containsAutoReply: true,
        mediaType: 1,
        jpegThumbnail: await getBuffer(global.img),
        mediaUrl: `https://youtube.com/@ZassOnee`,
        sourceUrl: `https://youtube.com/@ZassOnee`
      }
    }
  }, { quoted: qloc })
}
break;

//————————————————————//

case "self": {
if (!isCreator) return
zassbtz.public = false
reply("Berhasil Beralih Ke Mode Self")
}
break;

//————————————————————//

case "public": {
if (!isCreator) return
zassbtz.public = true
reply("Berhasil Beralih Ke Mode Public")
}
break;

//————————————————————//

case "scbot": case "sc": 
case "scriptbot": {
let teks = `*# Script ${botname}*
Script Ini Di Bagikan Secara Gratis Dengan Tujuan Edukasi.
Kamu bisa mendapatkan nya di channel YouTube kami.

*Youtube:* https://youtube.com/@ZassOnee
Ambil doang ga subs = GAY😏
*_© Credits By Zass Onee_*`
zassbtz.relayMessage(m.chat,  {requestPaymentMessage: {currencyCodeIso4217: 'IDR', amount1000: 35000000, requestFrom: m.sender, noteMessage: { extendedTextMessage: { text: teks, contextInfo: { externalAdReply: { showAdAttribution: true}}}}}}, {})
}
break;

//————————————————————//

case "upchannel": case "upch": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("teksnya"))
await zassbtz.sendMessage(idSaluran, {text: text})
reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break;

//————————————————————//

case "xnxx": case "xnxxdl": {
if (!q) return reply(example("linknya"))
let data = await func.fetchJson(`https://newapibot.rikishopreal.my.id/download/xnxx?apikey=newapi2025&url=${q}`)
if (!data.result) return reply("Result tidak ditemukan!")
await zassbtz.sendMessage(m.chat, {video: {url: data.result.files.high || data.result.files.low}, caption: "XNXX Download Done ✅", mimetype: "video/mp4"}, {quoted: m})
}
break;

//————————————————————//

case "videy": {
if (!text) return reply(example("linknya"))
reply("📥 Memproses videy downloader . .")
try {
let res = await fetch(`https://videy.co/api/download?url=${encodeURIComponent(text)}`)
let json = await res.json()
        
if (!json.success) return reply("Error! Video tidak ditemukan")
        
let videoUrl = json.result.video_url
let videoTitle = json.result.title || "Video"
        
await zassbtz.sendMessage(m.chat, {video: {url: videoUrl}, caption: `🎥 *${videoTitle}*`}, {quoted: m})
await zassbtz.sendMessage(m.chat, {react: {text: '', key: m.key}})
} catch (e) {
return reply("Error! Result Not Found")
}
}
break;

//————————————————————//

case "formatjp": case "jp": {
const text14 =`*FORMAT JASA POST ${namaOwner} !*  
( BUKAN MILIK ADMIN )

⭔ NAMA PEMILIK : 
⭔ ITEM : 
⭔ LOGIN : 
⭔ HARGA : 
⭔ INC/EX : 
⭔ SPEK : 
⭔ MC : 
⭔ NO SELLER : wa.me//62

✅ TAWAR MENAWAR HUB NO SELLER !
*GUNAKAN JASA ADMIN [ ~${namaOwner}~ ]*
*BIAR GA KE RIP ATAU KE TIPU*
`
reply(text14)
}
break;

//————————————————————//

case "formatned": case "ned": {
const text15 =`*🔰 FORMAT CARI AKUN BY ${namaOwner} 🔰*

*-CARI AKUN?* : 
*-OP/HARGA?* : 
*-LOG/LOGIN?* : 
*-SPECK AKUN?* : 
*-ADMIN/MC?* : 
*-NAMA PEMBELI* : 
*-NO PEMBELI* : wa.me//62xxx

*GUNAKAN JASA ADMIN* *[ ~${namaOwner}~ ]*
*BIAR KAGA KENA RIP/PENIPU*
`
reply(text15)
}
break;

//————————————————————//

case "feadmin": {
const text16 =`*FEE ADMIN ${namaOwner}*
PAYMENT : OVO - GO-PAY - DANA - QRIS
0K - 10K = 3K
11K - 50K = 5K
51K - 100K 10K
101K - 150K = 15K
151k - 200K = 20K 
201K - 250K = 25K
251K - 300K = 30K
301K - 400K = 35K
401K - 500K = 40K
DAN SETERUSNYA
*JIKA TRX BATAL FEE TETAP TERPOTONG*

*FEE MAHAL? GAPAPA MAHAL ASALKAN AMANAH DARI PADA MURAH TAPI DI BAWAH KABUR*`
reply(text16)
}
break;

//————————————————————//

case 'alrecc':
  case 'alrec':
  case 'allrecc':
  case 'alrecc':
  case 'allrec':{
let kurokost = `REKAM LAYAR!
//==============================================
> HAPUS SEMUA PESAN GMAIL
> KOSONGKAN SEMUA SAMPAH GMAIL
> HAPUS AKUN FB DARI PERANGKAT
> HAPUS AKUN GMAIL KALO BISA
> LOGOUT FF

*BY* ${namaOwner}`
reply(kurokost)
}
break;

//————————————————————//

case "autoread": {
if (!isCreator) return reply(mess.owner)
if (!text) return example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
if (text.toLowerCase() == "on") {
if (autoread) return m.reply("*Autoread* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoread = true
m.reply("*Berhasil Menyalakan Autoread ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!autoread) return m.reply("*Autoread* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoread = false
m.reply("*Berhasil Mematikan Autoread ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
}}
break;

//————————————————————//

case "autoreadsw": {
if (!isCreator) return reply(mess.owner)
if (!text) return example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
if (text.toLowerCase() == "on") {
if (autoreadsw) return m.reply("*Autoreadsw* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoreadsw = true
m.reply("*Berhasil Menyalakan Autoreadsw ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!autoreadsw) return m.reply("*Autoread* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoreadsw = false
m.reply("*Berhasil Mematikan Autoreadsw ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
}}
break;

//————————————————————//

case "anticall": {
if (!isCreator) return reply(mess.owner)
if (!text) return example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
if (text.toLowerCase() == "on") {
if (anticall) return m.reply("*Anticall* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
anticall = true
m.reply("*Berhasil Menyalakan Anticall ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!anticall) return m.reply("*Anticall* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
anticall = false
m.reply("*Berhasil Mematikan Anticall ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return m.reply(example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
}}
break;

//————————————————————//

case "welcome": {
  if (!isCreator) return reply(mess.owner);
  if (!text) return example("on/off\n\nKetik *.statusbot* untuk melihat status setting bot");

  if (text.toLowerCase() === "on") {
    if (global.welcome) return m.reply("*Welcome* sudah aktif!\n\nKetik *.statusbot* untuk melihat status setting bot");
    global.welcome = true
    m.reply("*Berhasil menyalakan Welcome ✅*\n\nKetik *.statusbot* untuk melihat status setting bot");
  } else if (text.toLowerCase() === "off") {
    if (!global.welcome) return m.reply("*Welcome* sudah tidak aktif!\n\nKetik *.statusbot* untuk melihat status setting bot");
    global.welcome = false
    m.reply("*Berhasil mematikan Welcome ✅*\n\nKetik *.statusbot* untuk melihat status setting bot");
  } else {
    return m.reply(example("on/off\n\nKetik *.statusbot* untuk melihat status setting bot"));
  }
}
break;

//————————————————————//

case "setting": case "settingbot": case "option": case "statusbot": {
if (!isCreator) return reply(mess.owner)
var teks = `
*List Status Setting Bot :*

* Autoread : ${global.autoread ? "*Aktif*" : "*Tidak Aktif*"}
* Autoreadsw : ${global.autoreadsw ? "*Aktif*" : "*Tidak Aktif*"}
* Anticall : ${global.anticall ? "*Aktif*" : "*Tidak Aktif*"}
* Welcome : ${global.welcome ? "*Aktif*" : "*Tidak Aktif*"}

*Contoh Penggunaan :*
Ketik *.autoread* on/off`
m.reply(teks)
}
break;

//————————————————————//

case "setnamabot": {
if (!isCreator) return reply(mess.owner);
if (!text) return example("teksnya")
zassbtz.updateProfileName(text)
m.reply("*Berhasil Mengganti Nama Bot ✅*")
}
break;

//————————————————————//

case "setbio": case "setbiobot": {
if (!isCreator) return reply(mess.owner);
if (!text) return example("teksnya")
zassbtz.updateProfileStatus(text)
m.reply("*Berhasil Mengganti Bio Bot ✅*")
}
break;

//————————————————————//

case 'pppanjang': case 'setppbot':{
if (!isCreator) return reply(mess.owner)
if (!quoted) return example(`Reply foto yg ingin di jadikan pp`)
if (!/image/.test(mime)) return reply(`Reply foto`)
if (/webp/.test(mime)) return reply(`Reply foto`)
let media = await zassbtz.downloadAndSaveMediaMessage(quoted)
var { img } = await generateProfilePicture(media)
await zassbtz.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
} 
]
})
m.reply("Bueress!!!")
}
break;

//————————————————————//

case "rst":
case "restart": {
  if (!isCreator) return reply(mess.owner);

  await reply("Tunggu sebentar, bot sedang restart...");

  try {
    if (zassbtz?.ws?.close) {
      await zassbtz.ws.close();
    }
    if (zassbtz?.ev?.removeAllListeners) {
      zassbtz.ev.removeAllListeners();
    }
  } catch (err) {
    console.error("Error saat menutup koneksi:", err);
  }

  // Restart proses
  process.exit(0);

  break;
}

//================ [ DEFAULT ] ================//
default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

if (m.text.toLowerCase() == "bot") {
reply("Bot Online ✅")
}

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) return reply(stdout)
})
}


}} catch (err) {
console.log(util.format(err));
zassbtz.sendMessage(obj + "@s.whatsapp.net", {text: '*Fitur Error Terdeteksi*\n\n*Log error :*\n' + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});