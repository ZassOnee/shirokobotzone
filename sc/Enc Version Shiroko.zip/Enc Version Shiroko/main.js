require("./system/global")
const figlet = require('figlet');
const chalk = require('chalk');
const gradient = require('gradient-string');
const func = require("./system/place")
const readline = require("readline")
const yargs = require("yargs")
const axios = require("axios")
const { Boom } = require('@hapi/boom');
const { loadModule } = require("./system/function.js")
const { useMultiFileAuthState, makeInMemoryStore, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino')
const fs = require("fs")

const usePairingCode = true

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

const DataBase = require('./system/database.js');
const database = new DataBase();
(async () => {
  const loadData = await database.read()
  if (!loadData || Object.keys(loadData).length === 0) {
    global.db = {
      users: {},
      groups: {},
      database: {},
      settings: {},
    }
    await database.write(global.db)
  } else {
    global.db = loadData
  }
  setInterval(async () => {
    if (global.db) await database.write(global.db)
  }, 5000)
})()

async function startSesi() {
  const ora = (await import('ora')).default;

  const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
  const { state, saveCreds } = await useMultiFileAuthState(`./session`)

  const connectionOptions = {
    version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
    browser: ['Ubuntu', 'Safari', '18.1'],
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
        return msg?.message || undefined
      }
      return { conversation: 'hallo' }
    },
    printQRInTerminal: !usePairingCode,
    logger: pino({ level: "silent" }),
    auth: state
  }

  const Zassonee = await func.makeWASocket(connectionOptions);
  await store?.bind(Zassonee.ev);

  if (
    usePairingCode &&
    Zassonee.authState &&
    Zassonee.authState.creds &&
    !Zassonee.authState.creds.registered
  ) {
    try {
      console.log(gradient.passion.multiline(`
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@,,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@,,,,,,,,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@,,,,,,,,,,,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@,,,,,,,,,,,,,@@@,,,,,,,,,@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@,,,,,,,,,,,,,,,,,@@@,,,,,,,,@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@,,,,,,,,,,,,,,,,,,,@@@@,,,,,,,@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@,,,,,,,,,@@@@@@@@@@@@,,,,,,,,,@@@@@,,,,,,,,@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@,,,,,,,,@@@@@@@@@@@@,,,,,,,,,@@@@@@@@,,,,,,,@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@,,,,,,,,,,,,,,,,,,,@@,,,,,,,,@@@@@@@@@,,,,,,,@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@,,,,,,,,,,,,,,,,,,@,,,,,,,,,@@@@@@@@@,,,,,,,,@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@,,,,,,,,,,,,,,@,,,,,,,,,@,,,,,,,@,,,,,,,,,@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,@@,,,@@,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,,,,,,,,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,,,,,,,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@,,,,,,,,,,,,,,,,,,,,@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
`));
      console.log(chalk.magentaBright('\n╭────[ SHIROKO PAIRING MODE ]─────'));
      console.log(chalk.cyanBright('│ Silakan masukkan nomor WhatsApp kamu:'));
      console.log(chalk.red('│ Format: 628xxxxxxxxxx (tanpa spasi atau simbol)'));
      console.log(chalk.magentaBright('╰─────────────────────────────────\n'));

      const phoneNumber = await question(chalk.greenBright('>> Nomor WhatsApp: '));
      const code = await Zassonee.requestPairingCode(phoneNumber.trim());

      console.log(chalk.yellowBright('\n╭────[ KODE PAIRING SIAP! ]────'));
      console.log(`${chalk.green('│ Kode:')} ${chalk.whiteBright.bold(code)}`);
      console.log(chalk.red('│ Masukkan kode ini lewat WhatsApp kamu (pengaturan > perangkat tertaut)'));
      console.log(chalk.yellowBright('╰───────────────────────────────\n'));
    } catch (e) {
      console.log(chalk.redBright('\n[!] Gagal request pairing code:'));
      console.log(chalk.gray(e.message || e));
    } finally {
      rl.close();
    }
  }

  Zassonee.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update
    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output.statusCode
      console.log(lastDisconnect.error)
      switch (reason) {
        case DisconnectReason.badSession:
          console.log(`Bad Session File, Please Delete Session and Scan Again`); break
        case DisconnectReason.connectionClosed:
          console.log('[SYSTEM]\nConnection closed, reconnecting...'); break
        case DisconnectReason.connectionLost:
          console.log('[SYSTEM]\nConnection lost, trying to reconnect'); break
        case DisconnectReason.connectionReplaced:
          console.log('Connection Replaced, Please Close Other Session');
          return Zassonee.logout()
        case DisconnectReason.restartRequired:
          console.log('Restart Required...'); return startSesi()
        case DisconnectReason.loggedOut:
          console.log(`Device Logged Out, Please Scan Again.`); return Zassonee.logout()
        case DisconnectReason.timedOut:
          console.log('Connection TimedOut, Reconnecting...'); return startSesi()
        default:
          return process.exit()
      }
    } else if (connection === "open") {
      loadModule(Zassonee)
      console.log(chalk.greenBright(`
╭───[ SHIROKO STATUS ]───╮
│ ✅ Tersambung ke WhatsApp!
│ Versi: 2.0.0
╰────────────────────────╯
`));
      Zassonee.sendMessage("6285298027445@s.whatsapp.net", {
        text:
          "╭───〔 *Shiroko Assistant Connected* 〕───╮\n" +
          "│ Status : ✅ *Online & Stable*\n" +
          "│ Versi  : 2.0.0 | *Encryption*\n" +
          "│ Owner  : Zass Onee\n" +
          "│ Terima kasih telah menggunakan script ini!\n" +
          "╰────────────────────────────────────╯"
      });
    }
  });

  Zassonee.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      let m = chatUpdate.messages[0]
      if (!m.message) return
      m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
      if (m.key && m.key.remoteJid === 'status@broadcast') return
      if (!Zassonee.public && m.key.remoteJid !== global.owner+"@s.whatsapp.net" && !m.key.fromMe && chatUpdate.type === 'notify') return
      m = await func.smsg(Zassonee, m, store)
      if (m.isBaileys) return
      require("./zassenc.js")(Zassonee, m, store)
    } catch (err) {
      console.log(err)
    }
  });

  Zassonee.ev.on('contacts.update', (update) => {
    for (let contact of update) {
      let id = Zassonee.decodeJid(contact.id)
      if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
    }
  });

  Zassonee.ev.on('creds.update', saveCreds)
  Zassonee.public = true
  return Zassonee
}

startSesi()

process.on('uncaughtException', function (err) {
  console.log('Caught exception: ', err)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
  delete require.cache[file]
  require(file)
})

const handleCommand = async (command) => {
  const args = command.trim().split(' ')
  const cmd = args[0].toLowerCase()

  switch (cmd) {
    case 'addproduk': {
      if (args.length < 4) return console.log('Format: addproduk <nama> <harga> <url_gambar>')
      const namaProduk = args[1]
      const hargaProduk = parseInt(args[2])
      const gambarProduk = args[3]
      if (!global.db) global.db = {}
      if (!global.db.produk) global.db.produk = {}
      global.db.produk[namaProduk] = {
        harga: hargaProduk,
        gambar: gambarProduk
      }
      console.log(`Produk "${namaProduk}" berhasil ditambahkan dengan harga Rp${hargaProduk}`)
      break
    }
    case 'delproduk': {
      if (args.length < 2) return console.log('Format: delproduk <nama>')
      const namaHapus = args[1]
      if (global.db.produk && global.db.produk[namaHapus]) {
        delete global.db.produk[namaHapus]
        console.log(`Produk "${namaHapus}" berhasil dihapus`)
      } else {
        console.log(`Produk "${namaHapus}" tidak ditemukan`)
      }
      break
    }
    case 'listproduk': {
      if (!global.db.produk || Object.keys(global.db.produk).length === 0) {
        console.log('Belum ada produk yang tersedia.')
      } else {
        console.log('Daftar Produk:')
        Object.entries(global.db.produk).forEach(([nama, data]) => {
          console.log(`- ${nama}: Rp${data.harga} | Gambar: ${data.gambar}`)
        })
      }
      break
    }
    default:
      console.log('Perintah tidak dikenali.')
  }
} // Penutup handleCommand
