/*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  🔰 SRIPT SHIROKO ASSISTANT OFFICIAL
  
  📞 Contact  : https://heylink.me/zass.id
  💸 Status   : Premium - No Encrypt
  💰 Harga    : Rp 10.000 (Lifetime)

  ⚠️ Note:
     Script ini tidak dibagikan secara gratis.
     Silakan hubungi kontak di atas jika ingin membeli.
© Zass Official Team
[ ! ] Jangan di hapus/ganti
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
require("./system/module.js")

// ╭─[ SHIROKO SYSTEM CONFIG | Bot Setting ]─╮ //
global.owner = "6285298027445"
global.ownernumber = ['6285298027445@s.whatsapp.net']
global.namabot = "Asisten Shiroko V 2.0.0" 
global.namaowner = "Zass Onee"
global.linkgc = 'https://chat.whatsapp.com/JmnfKXE8sYRGV6YCiF36UE'
global.linksaluran = "https://whatsapp.com/channel/0029VaplrGI0gcfJ7mQknX0E"
global.fotomenu = "https://img12.pixhost.to/images/1526/585603404_imgtmp.jpg"
global.menugif = "https://cdn.videy.co/tr3fYOGJ1.mp4"
global.image = "https://files.catbox.moe/ncrz1u.jpg"
global.vn = "https://files.catbox.moe/fr1dh3.mp3"
global.packname = "Zass Official Botz"
global.author = "SuaminyaShiroko"

// ╭─[ SHIROKO SYSTEM CONFIG | Broadcast Setting ]─╮ //
global.delayjpmch = 3000 // delay jpmch (default 2 detik)
global.delaypush = 5000 // delay pushkontak (default 5 detik)
global.jpm = 4000 // jpm default 4 detik
// Note : 1000 = 1 detik

// ╭─[ SHIROKO SYSTEM CONFIG | Store Setting ]─╮ //
global.allsosmed = "https://heylink.me/zass.id"
global.namatoko = "ARDY SHOP"
global.rating = "⭐️⭐️⭐️☆☆"


// ╭─[ SHIROKO SYSTEM CONFIG | Channel  Setting ]─╮ //
global.idsaluran = "120363335599553175@newsletter"
global.namasaluran = "Zass Official - Testimoni"

// ╭─[ SHIROKO SYSTEM CONFIG | Payment  Setting ]─╮ //
global.dana = "085298027445"
global.ovo = "Belum tersedia"
global.gopay = "085298027445"
global.qris = "https://files.catbox.moe/3zu1hd.jpg"


// ╭─[ SHIROKO SYSTEM CONFIG | Panel Setting ]─╮ //
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "-"
global.apikey = "-" // Isi api ptla
global.capikey = "-" // Isi api ptlc


// ╭─[ SHIROKO SYSTEM CONFIG ]─╮ //

global.msg = {
  wait: "⏳ Tunggu sebentar ya, sedang diproses...",
  owner: "❗ Fitur ini hanya bisa digunakan oleh *Owner*!",
  group: "👥 Fitur ini hanya dapat dijalankan di dalam *Group*!",
  admin: "⚠️ Fitur ini khusus untuk *Admin Group*!",
  botadmin: "⚙️ Fitur ini membutuhkan bot sebagai *Admin Group*!"
};

// ╭─[ SHIROKO SYSTEM CONFIG ]─╮ //
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "uByz8U9jRoor5FiZekdcNhzlWBpr9mekqVaXgR1w"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})