require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285298027445"
global.namaowner = "Zass Onee"
global.namaowner2 = "YT NeoShiroko Labs"

//======== Setting Bot & Link ========//
global.namabot = "Kuroko Linker" 
global.namabot2 = "KuroPush"
global.version = "v1.0.0"
global.foother = "Created By Zass Onee"

global.linkgc = 'https://chat.whatsapp.com/BlEl1NOINWR17TL70zpa2k'
global.linksaluran = "https://whatsapp.com/channel/0029Vb615brAzNbywHCyRc1w"
global.linkyt = 'https://www.youtube.com/@zassonee'
global.linktele = "https://t.me/zasstamvan"
global.web = "https://www.neolabsofficial.my.id"

global.packname = "Created By Kuroko Botz"
global.author = "https://www.neolabsofficial.my.id"

global.namach = "Neo-S Labs Official || Channels"
global.idch = "120363417526801494@newsletter"

//========== Setting Event ==========//
global.autoread = false
global.anticall = false
global.autoreadsw = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 4500
global.delayjpm = 1000

//========== Setting Foto ===========//
global.thumb = "https://files.catbox.moe/49j4go.jpg"
global.img = "https://files.catbox.moe/iwznkd.jpg"
global.thumbxm = "https://files.catbox.moe/q57r0k.jpg"
global.thumbbc = "https://files.catbox.moe/lrfpvb.jpg"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "085298027445"
global.gopay = "085298027445"
global.ovo = false
global.qris = "https://files.catbox.moe/3zu1hd.jpg"

//========= Setting Payment =========// 
global.namadana = "FallZx Store"
global.namagopay = "Fall"
global.namaovo = "Fall" 

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Bueress Omm", 
"wait": "Loading. . .", 
"group": "*• Group Only* This Feature Is Only For Within Groups!", 
"private": "*• Private Chat* This Feature Is Only For Within Groups!", 
"owner": "*• Owner Only* This feature is only for Bot Owners!", 
"developer": "*• Developer Only* This Feature Is For Developers Only"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})